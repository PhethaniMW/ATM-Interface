//Maanda Phethani Wisdom
//28 February 2024
//A number guessing game with user interaction.
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

// Class definition for the number guessing game GUI
public class NumberGuessingGameGUI extends JFrame {
    // Instance variables declaration
    private int secretNumber; // The secret number to be guessed
    private int totalAttempts; // Total number of attempts allowed per round
    private int currentRound; // Current round number
    private int score; // Player's score

    // GUI components declaration
    private JLabel guessLabel; // Label prompting the user to enter a guess
    private JTextField guessField; // Text field for entering guesses
    private JButton submitButton; // Button to submit guesses
    private JLabel scoreLabel; // Label displaying the player's score
    private JLabel roundLabel; // Label displaying the current round number

    // Constructor for the NumberGuessingGameGUI class
    public NumberGuessingGameGUI() {
        // Call to the superclass constructor to set the title and default close operation
        super("Number Guessing Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        // Initialize instance variables
        secretNumber = new Random().nextInt(100) + 1;
        totalAttempts = 5;
        currentRound = 1;
        score = 0;

        // Create and initialize GUI components
        guessLabel = new JLabel("Enter your guess (1-100): ");
        guessField = new JTextField(10);
        submitButton = new JButton("Submit");
        scoreLabel = new JLabel("Score: " + score);
        roundLabel = new JLabel("Round: " + currentRound);

        // Add action listener to the submit button
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkGuess(); // Call checkGuess method when the submit button is clicked
            }
        });

        // Add GUI components to the JFrame
        add(guessLabel);
        add(guessField);
        add(submitButton);
        add(scoreLabel);
        add(roundLabel);

        setVisible(true); // Make the JFrame visible
    }

    // Method to check the user's guess
    private void checkGuess() {
        try {
            int guess = Integer.parseInt(guessField.getText()); // Parse the user's guess from the text field
            totalAttempts--; // Decrement the total attempts remaining

            // Check if the guess is too low
            if (guess < secretNumber) {
                JOptionPane.showMessageDialog(this, "Too low! Try again.");
            } 
            // Check if the guess is too high
            else if (guess > secretNumber) {
                JOptionPane.showMessageDialog(this, "Too high! Try again.");
            } 
            // If the guess is correct
            else {
                JOptionPane.showMessageDialog(this, "Congratulations! You guessed the number.");
                score += totalAttempts * 10; // Add points based on remaining attempts
                scoreLabel.setText("Score: " + score); // Update the score label
                resetRound(); // Reset the round for a new game
            }

            // Check if the player has run out of attempts
            if (totalAttempts == 0) {
                JOptionPane.showMessageDialog(this, "Out of attempts! The number was " + secretNumber);
                resetRound(); // Reset the round for a new game
            }
        } 
        // Handle NumberFormatException if the user enters invalid input
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number.");
        }
    }

    // Method to reset the round for a new game
    private void resetRound() {
        secretNumber = new Random().nextInt(100) + 1; // Generate a new secret number
        totalAttempts = 5; // Reset the total attempts
        currentRound++; // Increment the round number
        roundLabel.setText("Round: " + currentRound); // Update the round label
    }

    // Main method to start the application
    public static void main(String[] args) {
        // Create and show the GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new NumberGuessingGameGUI(); // Create an instance of the NumberGuessingGameGUI class
            }
        });
    }
}
