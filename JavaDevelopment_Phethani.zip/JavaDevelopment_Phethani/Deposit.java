//Maanda Phethani
//deposit functionality
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

// Class for deposit panel
public class Deposit extends JPanel {
    private JTextField depositField;
    private TransactionHistory transactionHistory;

    public Deposit(TransactionHistory transactionHistory) {
        setBackground(new Color(173, 216, 230)); // Same as background color

        this.transactionHistory = transactionHistory;

        // Create and initialize deposit panel
        JLabel depositLabel = new JLabel("Deposit Amount:");
        depositField = new JTextField(10);
        JButton depositButton = new JButton("Deposit");
        add(depositLabel);
        add(depositField);
        add(depositButton);

        // Add action listener to the deposit button
        depositButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Perform deposit
                double amount = Double.parseDouble(depositField.getText());
                if (amount > 0) {
                    transactionHistory.addTransaction("Deposit: +R" + amount);
                } else {
                    JOptionPane.showMessageDialog(Deposit.this, "Invalid amount. Please enter a positive value.");
                }
                depositField.setText(""); // Clear deposit field after deposit
            }
        });
    }
}
