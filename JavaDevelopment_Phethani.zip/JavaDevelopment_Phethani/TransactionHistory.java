import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.awt.Color;

// Class for transaction history panel
public class TransactionHistory extends JPanel {
    private JTextArea transactionHistoryTextArea;
    private ArrayList<String> transactions;

    public TransactionHistory() {
        setBackground(new Color(173, 216, 230)); // Same as background color

        // Initialize transactions list
        transactions = new ArrayList<>();

        // Create and initialize transaction history panel
        JLabel historyLabel = new JLabel("Transaction History:");
        transactionHistoryTextArea = new JTextArea(10, 20);
        transactionHistoryTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(transactionHistoryTextArea);
        add(historyLabel);
        add(scrollPane);
    }

    // Method to add a transaction to the transaction history
    public void addTransaction(String transaction) {
        transactions.add(transaction);
        updateTransactionHistory();
    }

    // Method to update the transaction history display
    private void updateTransactionHistory() {
        transactionHistoryTextArea.setText("");
        for (String transaction : transactions) {
            transactionHistoryTextArea.append(transaction + "\n");
        }
    }
}
