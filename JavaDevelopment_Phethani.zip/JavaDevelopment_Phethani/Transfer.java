import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

// Class for transfer panel
public class Transfer extends JPanel {
    private JTextField recipientField;
    private JTextField amountField;
    private TransactionHistory transactionHistory;

    public Transfer(TransactionHistory transactionHistory) {
        setBackground(new Color(173, 216, 230)); // Same as background color

        this.transactionHistory = transactionHistory;

        // Create and initialize transfer panel
        JLabel recipientLabel = new JLabel("Recipient:");
        recipientField = new JTextField(10);
        JLabel transferAmountLabel = new JLabel("Amount:");
        amountField = new JTextField(10);
        JButton transferButton = new JButton("Transfer");
        add(recipientLabel);
        add(recipientField);
        add(transferAmountLabel);
        add(amountField);
        add(transferButton);

        // Add action listener to the transfer button
        transferButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Perform transfer
                double amount = Double.parseDouble(amountField.getText());
                String recipient = recipientField.getText();
                if (amount > 0) {
                    transactionHistory.addTransaction("Transfer to " + recipient + ": -R" + amount);
                } else {
                    JOptionPane.showMessageDialog(Transfer.this, "Invalid amount. Please enter a positive value.");
                }
                amountField.setText(""); // Clear amount field after transfer
                recipientField.setText(""); // Clear recipient field after transfer
            }
        });
    }
}
