//Maanda Phethani
//User interaction , THE GUI
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

// Class for the ATM interface
public class WiseATMInterface extends JFrame {
    private UserManagement userManagement;
    private TransactionHistory transactionHistory;
    private Withdrawal withdrawal;
    private Deposit deposit;
    private Transfer transfer;
    private JTextField userIdField;
    private JPasswordField pinField;

    public WiseATMInterface() {
        setTitle("The Wise ATM");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Set blue and white background
        getContentPane().setBackground(new Color(173, 216, 230));

        // Create logo panel
        JPanel logoPanel = new JPanel();
        logoPanel.setBackground(new Color(173, 216, 230)); // Same as background color
        //JLabel logoLabel = new JLabel(new ImageIcon("tree_logo.png"));
        //logoPanel.add(logoLabel);
        add(logoPanel, BorderLayout.NORTH);

        // Create center panel for login
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(3, 1));
        centerPanel.setBackground(new Color(173, 216, 230)); // Same as background color

        // Initialize components
        userManagement = new UserManagement();
        transactionHistory = new TransactionHistory();
        withdrawal = new Withdrawal(transactionHistory);
        deposit = new Deposit(transactionHistory);
        transfer = new Transfer(transactionHistory);
        userIdField = new JTextField(10);
        pinField = new JPasswordField(10);
        JButton loginButton = new JButton("Login");

        // Create and initialize login panel
        JPanel loginPanel = new JPanel();
        loginPanel.setBackground(new Color(173, 216, 230)); // Same as background color
        JLabel userIdLabel = new JLabel("User ID:");
        JLabel pinLabel = new JLabel("PIN:");
        loginPanel.add(userIdLabel);
        loginPanel.add(userIdField);
        loginPanel.add(pinLabel);
        loginPanel.add(pinField);
        loginPanel.add(loginButton);
        centerPanel.add(loginPanel);

        // Add center panel to the frame
        add(centerPanel, BorderLayout.CENTER);

        // Add action listener to the login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get user ID and PIN entered by the user
                String userId = userIdField.getText();
                String pin = new String(pinField.getPassword());

                // Authenticate user
                if (userManagement.authenticateUser(userId, pin)) {
                    JOptionPane.showMessageDialog(WiseATMInterface.this, "Login successful!");
                    // Proceed to display ATM functionalities
                    displayATMFunctionalities();
                } else {
                    JOptionPane.showMessageDialog(WiseATMInterface.this, "Invalid user ID or PIN. Please try again.");
                    // Clear user ID and PIN fields
                    userIdField.setText("");
                    pinField.setText("");
                }
            }
        });
    }

    // Method to display ATM functionalities upon successful login
    private void displayATMFunctionalities() {
        // Remove login panel
        getContentPane().removeAll();
        repaint();

        // Create new center panel for ATM functionalities
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(4, 1));
        centerPanel.setBackground(new Color(173, 216, 230)); // Same as background color

        // Add transaction history panel
        centerPanel.add(transactionHistory);

        // Add withdrawal panel
        centerPanel.add(withdrawal);

        // Add deposit panel
        centerPanel.add(deposit);

        // Add transfer panel
        centerPanel.add(transfer);

        // Add center panel to the frame
        add(centerPanel, BorderLayout.CENTER);
        revalidate();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new WiseATMInterface().setVisible(true);
            }
        });
    }
}
