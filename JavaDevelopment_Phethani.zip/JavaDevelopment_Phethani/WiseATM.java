//Maanda Phethani
// Main class to start the application
import javax.swing.SwingUtilities;
//Main class
public class WiseATM {
    public static void main(String[] args) {
        // Create an instance of the ATM interface
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new WiseATMInterface().setVisible(true);
            }
        });
    }
}
