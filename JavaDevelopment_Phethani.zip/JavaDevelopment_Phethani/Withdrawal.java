//Maanda Phethani
//Deposit functionality
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

// Class for withdrawal panel
public class Withdrawal extends JPanel {
    private JTextField amountField;
    private TransactionHistory transactionHistory;

    public Withdrawal(TransactionHistory transactionHistory) {
        setBackground(new Color(173, 216, 230)); // Same as background color

        this.transactionHistory = transactionHistory;

        // Create and initialize withdrawal panel
        JLabel withdrawLabel = new JLabel("Withdraw Amount:");
        amountField = new JTextField(10);
        JButton withdrawButton = new JButton("Withdraw");
        add(withdrawLabel);
        add(amountField);
        add(withdrawButton);

        // Add action listener to the withdraw button
        withdrawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Perform withdrawal
                double amount = Double.parseDouble(amountField.getText());
                if (amount > 0) {
                    transactionHistory.addTransaction("Withdrawal: -R" + amount);
                } else {
                    JOptionPane.showMessageDialog(Withdrawal.this, "Invalid amount. Please enter a positive value.");
                }
                amountField.setText(""); // Clear amount field after withdrawal
            }
        });
    }
}
