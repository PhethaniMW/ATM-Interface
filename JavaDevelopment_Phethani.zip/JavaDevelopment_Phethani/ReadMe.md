ReadMe file.
Maanda Phethani

---
 Number Guessing Game

Welcome to the Number Guessing Game! This simple Java application allows users to guess a randomly generated number within a specified range.

Features

- Generates a random number between 1 and 100.
- Allows the user to guess the number.
- Provides feedback on whether the guess is too high or too low.
- Limits the number of attempts.
- Tracks the score based on the number of attempts.
- Supports multiple rounds with different secret numbers.

How to Play

1. Run the application.
2. Enter your guess in the text field provided.
3. Click the "Submit" button to submit your guess.
4. Receive feedback on your guess.
5. Keep guessing until you guess the correct number or run out of attempts.
6. After each round, the score is updated based on the number of attempts left.
7. Start a new round to continue playing.

Installation

1. Clone the repository or download the source code files.
2. Open the project in your preferred Java IDE.
3. Compile the Java files.
4. Run the `NumberGuessingGameGUI` class to start the game.

Dependencies

This application is written in Java and does not require any external dependencies.
Contributors

- Phethani Maanda - maandawisdom@gmail.com
