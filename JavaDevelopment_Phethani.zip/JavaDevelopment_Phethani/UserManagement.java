import java.util.HashMap;
import java.awt.Color;

// Class for user management (authentication)
public class UserManagement {
    private HashMap<String, String> userCredentials;

    public UserManagement() {
        // Initialize user credentials (hard-coded for demonstration purposes)
        userCredentials = new HashMap<>();
        userCredentials.put("user1", "1234");
        userCredentials.put("user2", "5678");
    }

    // Method to authenticate user
    public boolean authenticateUser(String userId, String pin) {
        // Check if user ID exists in userCredentials and if the corresponding PIN matches
        return userCredentials.containsKey(userId) && userCredentials.get(userId).equals(pin);
    }
}
